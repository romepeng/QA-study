# CTP WIN/LINUX BROKER

from QUANTAXIS.QAMarket.QABroker import QA_Broker


class CTPBroker(QA_Broker):

    def __init__(self):
        pass
