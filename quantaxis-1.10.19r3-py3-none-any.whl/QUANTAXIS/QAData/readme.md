# QA_DataStruct


DataStruct具有的功能:

- 数据容器
- 数据变换 [分拆/合并/倒序] split/merge/reverse
- 数据透视 pivot
- 数据筛选 select_time/select_time_with_gap/select_code/get_bar
- 数据复权 to_qfq/to_hfq
- 数据显示 show
- 格式变换 to_json/to_pandas/to_list/to_numpy
- 数据库式查询  query
- 画图 plot